(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const a of o)if(a.type==="childList")for(const s of a.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&r(s)}).observe(document,{childList:!0,subtree:!0});function t(o){const a={};return o.integrity&&(a.integrity=o.integrity),o.referrerPolicy&&(a.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?a.credentials="include":o.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function r(o){if(o.ep)return;o.ep=!0;const a=t(o);fetch(o.href,a)}})();const k="workTrackerDB",I=1;async function m(){return new Promise((n,e)=>{const t=indexedDB.open(k,I);t.onerror=()=>{e(new Error("Error al abrir la base de datos"))},t.onsuccess=()=>{n(t.result)},t.onupgradeneeded=r=>{const o=r.target.result;o.objectStoreNames.contains("workers")||o.createObjectStore("workers",{keyPath:"id"}),o.objectStoreNames.contains("jobs")||o.createObjectStore("jobs",{keyPath:"id"})}})}const w="work-tracker-db",x=1;class D{constructor(){this.db=null,this.initDB()}async initDB(){return new Promise((e,t)=>{const r=indexedDB.open(w,x);r.onupgradeneeded=o=>{console.log("Creando/actualizando estructura de base de datos");const a=o.target.result;a.objectStoreNames.contains("jobs")||(a.createObjectStore("jobs",{keyPath:"id"}),console.log("Almacén 'jobs' creado")),a.objectStoreNames.contains("workers")||(a.createObjectStore("workers",{keyPath:"id"}),console.log("Almacén 'workers' creado")),a.objectStoreNames.contains("sync-queue")||(a.createObjectStore("sync-queue",{keyPath:"id",autoIncrement:!0}),console.log("Almacén 'sync-queue' creado")),console.log("Estructura de base de datos actualizada")},r.onsuccess=o=>{this.db=o.target.result,console.log("Conexión a IndexedDB establecida con éxito"),e(this.db)},r.onerror=o=>{console.error("Error al abrir la base de datos:",o.target.error),t(o.target.error)}})}async getAll(e){return await this.ensureDBInitialized(),new Promise((t,r)=>{if(!this.db){r(new Error("La base de datos no está inicializada"));return}try{const s=this.db.transaction(e,"readonly").objectStore(e).getAll();s.onsuccess=()=>{t(s.result)},s.onerror=i=>{r(i.target.error)}}catch(o){r(o)}})}async add(e,t){return await this.ensureDBInitialized(),new Promise((r,o)=>{if(!this.db){o(new Error("La base de datos no está inicializada"));return}try{const i=this.db.transaction(e,"readwrite").objectStore(e).add(t);i.onsuccess=()=>{r(i.result)},i.onerror=l=>{o(l.target.error)}}catch(a){o(a)}})}async update(e,t,r){try{const a=(await this.openDB()).transaction(e,"readwrite");return await a.objectStore(e).put(r),await a.complete,r}catch(o){throw console.error(`Error al actualizar en ${e}:`,o),o}}async delete(e,t){return await this.ensureDBInitialized(),new Promise((r,o)=>{if(!this.db){o(new Error("La base de datos no está inicializada"));return}try{const i=this.db.transaction(e,"readwrite").objectStore(e).delete(t);i.onsuccess=()=>{r()},i.onerror=l=>{o(l.target.error)}}catch(a){o(a)}})}async getById(e,t){return await this.ensureDBInitialized(),new Promise((r,o)=>{if(!this.db){o(new Error("La base de datos no está inicializada"));return}try{const i=this.db.transaction(e,"readonly").objectStore(e).get(t);i.onsuccess=()=>{r(i.result)},i.onerror=l=>{o(l.target.error)}}catch(a){o(a)}})}async ensureDBInitialized(){return this.db||await this.initDB(),this.db}async ensureStoresExist(){await this.ensureDBInitialized();try{const e=["jobs","workers","sync-queue"];let t=!1;const r=Array.from(this.db.objectStoreNames);for(const o of e)if(!r.includes(o)){console.warn(`El almacén ${o} no existe. Se necesita actualizar la base de datos.`),t=!0;break}return t&&(console.log("Actualizando estructura de la base de datos..."),await this.resetDatabase()),!0}catch(e){throw console.error("Error al verificar almacenes:",e),e}}async clearStore(e){return await this.ensureDBInitialized(),new Promise((t,r)=>{if(!this.db){r(new Error("La base de datos no está inicializada"));return}try{console.log(`Limpiando almacén: ${e}`);const s=this.db.transaction(e,"readwrite").objectStore(e).clear();s.onsuccess=()=>{console.log(`Almacén ${e} limpiado con éxito`),t(!0)},s.onerror=i=>{console.error(`Error al limpiar almacén ${e}:`,i.target.error),r(i.target.error)}}catch(o){console.error(`Error al limpiar almacén ${e}:`,o),r(o)}})}async resetDatabase(){return this.db&&(this.db.close(),this.db=null),new Promise((e,t)=>{console.log("Solicitando eliminación de la base de datos...");const r=indexedDB.deleteDatabase(w);r.onsuccess=()=>{console.log("Base de datos eliminada con éxito"),this.initDB().then(()=>{console.log("Base de datos recreada con éxito"),e(!0)}).catch(o=>{console.error("Error al recrear la base de datos:",o),t(o)})},r.onerror=o=>{console.error("Error al eliminar la base de datos:",o.target.error),t(o.target.error)},r.onblocked=()=>{console.warn("La eliminación de la base de datos está bloqueada"),alert("Por favor, cierre todas las demás pestañas con esta aplicación para reiniciar la base de datos"),t(new Error("Eliminación de base de datos bloqueada"))}})}}new D;function c(n,e="info",t=3e3){let r=document.getElementById("notifications-container");r||(r=document.createElement("div"),r.id="notifications-container",r.style.cssText=`
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
    `,document.body.appendChild(r));const o=document.createElement("div");o.className=`notification notification-${e}`,o.style.cssText=`
    margin-bottom: 10px;
    padding: 15px 25px 15px 15px;
    border-radius: 4px;
    color: white;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-width: 300px;
    max-width: 500px;
    animation: slideIn 0.3s ease-out;
  `;const a={success:"#28a745",info:"#17a2b8",warning:"#ffc107",danger:"#dc3545"};o.style.backgroundColor=a[e]||a.info;const s=document.createElement("div");s.textContent=n,s.style.flex="1";const i=document.createElement("button");if(i.innerHTML="×",i.style.cssText=`
    background: none;
    border: none;
    color: white;
    font-size: 20px;
    cursor: pointer;
    padding: 0 0 0 10px;
    opacity: 0.7;
  `,i.addEventListener("mouseover",()=>i.style.opacity="1"),i.addEventListener("mouseout",()=>i.style.opacity="0.7"),o.appendChild(s),o.appendChild(i),r.appendChild(o),!document.getElementById("notification-styles")){const h=document.createElement("style");h.id="notification-styles",h.textContent=`
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
      }
    `,document.head.appendChild(h)}const l=()=>{o.style.animation="slideOut 0.3s ease-out",setTimeout(()=>{o.parentElement&&o.parentElement.removeChild(o),r.children.length===0&&r.parentElement.removeChild(r)},300)};return i.onclick=l,t>0&&setTimeout(l,t),o.addEventListener("click",l),o}function p(){return Date.now().toString(36)+Math.random().toString(36).substr(2)}function v(n){return n?new Date(n).toLocaleDateString("es-ES",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"}):""}function S(n,e){return e.every(t=>{const r=n[t];return r!=null&&r!==""})}function q(n){if(!n)return"";const e=document.createElement("div");return e.textContent=n,e.innerHTML.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}class j{constructor(){this.workers=[],this.storeName="workers",this.initialized=!1}async init(){this.initialized||(await this.loadWorkers(),this.initialized=!0)}async loadWorkers(){try{const r=(await m()).transaction(this.storeName,"readonly").objectStore(this.storeName);return this.workers=await r.getAll(),this.workers}catch(e){throw console.error("Error loading workers:",e),c("Error al cargar los trabajadores","danger"),e}}async addWorker(e){try{this.validateWorkerData(e);const t=e.profileImage?await this.processImage(e.profileImage):null,r={id:p(),name:e.name,specialty:e.specialty,phone:e.phone||"",email:e.email||"",profileImage:t,hours:e.hours||0,jobs:e.jobs||[],createdAt:new Date().toISOString()};return await(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName).add(r),await this.loadWorkers(),c("Trabajador guardado con éxito","success"),r}catch(t){throw console.error("Error al añadir trabajador:",t),c(t.message||"Error al guardar el trabajador","danger"),t}}async deleteWorker(e){try{return await(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName).delete(e),await this.loadWorkers(),c("Trabajador eliminado con éxito","success"),!0}catch(t){throw console.error("Error al eliminar trabajador:",t),c("Error al eliminar el trabajador","danger"),t}}async updateWorker(e){try{this.validateWorkerData(e);const o=(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName),a=await o.get(e.id);if(!a)throw new Error("Trabajador no encontrado");let s=a.profileImage;e.profileImage&&e.profileImage!==a.profileImage&&(s=await this.processImage(e.profileImage));const i={...a,name:e.name,specialty:e.specialty,phone:e.phone||a.phone||"",email:e.email||a.email||"",profileImage:s,updatedAt:new Date().toISOString()};return await o.put(i),await this.loadWorkers(),c("Trabajador actualizado con éxito","success"),i}catch(t){throw console.error("Error al actualizar trabajador:",t),c(t.message||"Error al actualizar el trabajador","danger"),t}}async updateWorkerHours(e,t){try{if(isNaN(Number(t))||Number(t)<0)throw new Error("Las horas deben ser un número positivo");const a=(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName),s=await a.get(e);if(!s)throw new Error("Trabajador no encontrado");return s.hours=Number(s.hours||0)+Number(t),s.updatedAt=new Date().toISOString(),await a.put(s),await this.loadWorkers(),c(`Horas actualizadas para ${s.name}`,"success"),s}catch(r){throw console.error("Error al actualizar horas:",r),c(r.message||"Error al actualizar las horas","danger"),r}}getWorkerById(e){return this.workers.find(t=>t.id===e)}getWorkerStats(){const e=this.workers.length,t=this.workers.reduce((s,i)=>s+(Number(i.hours)||0),0),r=e>0?t/e:0;let o=null,a=0;for(const s of this.workers){const i=Number(s.hours)||0;i>a&&(a=i,o=s)}return{total:e,totalHours:t,averageHours:r,topWorker:o?{id:o.id,name:o.name,hours:a}:null}}validateWorkerData(e){const r=S(e,["name","specialty"]);if(r.length>0)throw new Error(`Campos requeridos faltantes: ${r.join(", ")}`);return!0}async processImage(e){return e?typeof e=="string"?e:new Promise((t,r)=>{const o=new FileReader;o.onloadend=()=>t(o.result),o.onerror=r,o.readAsDataURL(e)}):null}exportWorkerData(){const e=JSON.stringify(this.workers,null,2),t="data:application/json;charset=utf-8,"+encodeURIComponent(e),r=`trabajadores_${v(new Date)}.json`,o=document.createElement("a");o.setAttribute("href",t),o.setAttribute("download",r),o.click(),c("Datos de trabajadores exportados correctamente","success")}async reset(){try{return this.workers=[],!0}catch(e){return console.error("Error al restablecer el servicio de trabajadores:",e),!1}}getAllWorkers(){return this.workers}}class ${constructor(){this.jobs=[],this.storeName="jobs",this.workerService=new j,this.initialized=!1}async init(){this.initialized||(await Promise.all([this.loadJobs(),this.workerService.init()]),this.initialized=!0)}async loadJobs(){try{const r=(await m()).transaction(this.storeName,"readonly").objectStore(this.storeName);return this.jobs=await r.getAll(),this.jobs}catch(e){throw console.error("Error loading jobs:",e),c("Error al cargar los trabajos","danger"),e}}async addJob(e){try{return await(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName).add(e),await this.loadJobs(),!0}catch(t){throw console.error("Error adding job:",t),t}}async updateJob(e){try{return await(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName).put(e),await this.loadJobs(),!0}catch(t){throw console.error("Error updating job:",t),t}}async deleteJob(e){try{return await(await m()).transaction(this.storeName,"readwrite").objectStore(this.storeName).delete(e),await this.loadJobs(),!0}catch(t){throw console.error("Error deleting job:",t),t}}getJobById(e){return this.jobs.find(t=>t.id===e)}getAllJobs(){return this.jobs}getWorkerJobs(e){return this.jobs.filter(t=>t.workerId===e)}getJobStats(){const e=this.jobs.length,t=this.jobs.filter(a=>a.status==="Completado").length,r=this.jobs.filter(a=>a.status==="Pendiente").length,o=this.jobs.filter(a=>a.status==="En Progreso").length;return{total:e,completed:t,pending:r,inProgress:o,completionRate:e>0?t/e*100:0}}validateJobData(e){const r=S(e,["title","description","date","status"]);if(r.length>0)throw new Error(`Campos requeridos faltantes: ${r.join(", ")}`);return!0}async processImages(e){return!e||e.length===0?[]:typeof e[0]=="string"?e:Promise.all(Array.from(e).map(t=>new Promise((r,o)=>{const a=new FileReader;a.onloadend=()=>r(a.result),a.onerror=o,a.readAsDataURL(t)})))}async exportJobData(){const e=JSON.stringify(this.jobs,null,2),t="data:application/json;charset=utf-8,"+encodeURIComponent(e),r=`trabajos_${v(new Date)}.json`,o=document.createElement("a");o.setAttribute("href",t),o.setAttribute("download",r),o.click(),c("Datos de trabajos exportados correctamente","success")}async reset(){try{return this.jobs=[],!0}catch(e){return console.error("Error al restablecer el servicio de trabajos:",e),!1}}async completeJob(e){return this.updateJob(e,{status:"Completado"})}async startJob(e){return this.updateJob(e,{status:"En Progreso"})}getPendingJobs(){return this.jobs.filter(e=>e.status==="Pendiente")}getCompletedJobs(){return this.jobs.filter(e=>e.status==="Completado")}getInProgressJobs(){return this.jobs.filter(e=>e.status==="En Progreso")}}class W{constructor(){var e;this.jobsContainer=document.querySelector("#jobs-container"),this.workersContainer=document.querySelector("#workers-container"),this.notificationContainer=document.querySelector("#notification-container"),this.jobForm=document.querySelector("#jobForm"),this.workerForm=document.querySelector("#workerForm"),this.initializeModals(),this.jobTitleInput=document.querySelector("#titulo"),this.jobDescriptionInput=document.querySelector("#descripcion"),this.jobDateInput=document.querySelector("#fecha"),this.jobStatusSelect=document.querySelector("#estado"),this.jobWorkersSelect=document.querySelector("#trabajador"),this.jobSubmitButton=(e=this.jobForm)==null?void 0:e.querySelector('button[type="submit"]')}initializeModals(){if(typeof bootstrap<"u"){const e=document.querySelector("#jobDetailsModal"),t=document.querySelector("#workerDetailsModal");e&&(this.jobDetailsModal=new bootstrap.Modal(e)),t&&(this.workerDetailsModal=new bootstrap.Modal(t))}else console.warn("Bootstrap no está disponible. Los modales podrían no funcionar correctamente.")}showNotification(e,t="info"){const r=document.createElement("div");r.className=`alert alert-${t} alert-dismissible fade show`,r.role="alert",r.innerHTML=`
      ${e}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `,this.notificationContainer.appendChild(r),setTimeout(()=>{r.classList.remove("show"),setTimeout(()=>r.remove(),150)},3e3)}showJobDetailsModal(e){const t=document.querySelector("#jobDetailsModal .modal-body");t.innerHTML=`
      <div class="job-details">
        <h4>${e.title}</h4>
        <p class="text-muted mb-4">${e.description}</p>
        
        <div class="info-item mb-3">
          <strong>Estado:</strong>
          <span class="badge bg-${this.getStatusBadgeClass(e.status)}">${e.status}</span>
        </div>
        
        <div class="info-item mb-3">
          <strong>Fecha:</strong>
          <span>${this.formatDate(e.date)}</span>
        </div>
        
        ${this.renderAssignedWorkers(e)}
        ${this.renderJobImages(e)}
      </div>
    `,this.jobDetailsModal.show()}showWorkerDetailsModal(e){const t=document.querySelector("#workerDetailsModal .modal-body");t.innerHTML=`
      <div class="worker-details">
        <div class="d-flex align-items-center mb-4">
          ${this.renderWorkerAvatar(e)}
          <div>
            <h4>${e.name}</h4>
            <p class="text-muted mb-0">${e.specialty}</p>
          </div>
        </div>
        
        ${e.phone?`
          <div class="info-item mb-3">
            <strong>Teléfono:</strong>
            <p class="mb-0">${e.phone}</p>
          </div>
        `:""}
        
        ${e.email?`
          <div class="info-item mb-3">
            <strong>Email:</strong>
            <p class="mb-0">${e.email}</p>
          </div>
        `:""}
      </div>
    `,this.workerDetailsModal.show()}fillJobForm(e){this.jobTitleInput.value=e.title,this.jobDescriptionInput.value=e.description,this.jobDateInput.value=e.date,this.jobStatusSelect.value=e.status,this.jobWorkersSelect&&Array.from(this.jobWorkersSelect.options).forEach(t=>{var r;t.selected=(r=e.workerIds)==null?void 0:r.includes(t.value)}),this.jobSubmitButton&&(this.jobSubmitButton.textContent="Actualizar Trabajo",this.jobForm.dataset.editingJobId=e.id),this.jobForm.scrollIntoView({behavior:"smooth"})}resetJobForm(){this.jobForm.reset(),this.jobSubmitButton&&(this.jobSubmitButton.textContent="Guardar Trabajo"),delete this.jobForm.dataset.editingJobId}getStatusBadgeClass(e){return{Pendiente:"warning","En Progreso":"info",Completado:"success",pending:"warning","in-progress":"info",completed:"success"}[e]||"secondary"}formatDate(e){return new Date(e).toLocaleDateString()}renderAssignedWorkers(e){return!e.workerIds||e.workerIds.length===0?"":`
      <div class="info-item mb-3">
        <strong>Trabajadores Asignados:</strong>
        <div class="trabajadores-asignados mt-2">
          ${e.workers.map(t=>`
            <div class="trabajador-asignado">
              ${this.renderWorkerAvatar(t)}
              <div>
                <h5 class="mb-1">${t.name}</h5>
                <p class="mb-0">${t.specialty}</p>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `}renderWorkerAvatar(e){return e.photo?`<img src="${e.photo}" alt="${e.name}" class="worker-avatar me-3">`:`<div class="worker-avatar-placeholder me-3">
          <i class="fas fa-user"></i>
         </div>`}renderJobImages(e){return!e.images||e.images.length===0?"":`
      <div class="info-item mb-3">
        <strong>Fotos:</strong>
        <div class="fotos-trabajo mt-2">
          ${e.images.map(t=>`
            <img src="${t}" alt="Foto del trabajo" class="job-image me-2">
          `).join("")}
        </div>
      </div>
    `}}const f=/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);function y(n,e){switch(n=q(n),e){case"tel":return n.replace(/[^\d\s]/g,"").trim();case"email":return n.toLowerCase().replace(/\s/g,"");default:return n.trim()}}let d=null,u=null,g=!1;async function E(n){var e;if(!n){c("Error: No se proporcionó un elemento de entrada","danger");return}if(g){b();return}try{if(!d){const r=window.SpeechRecognition||window.webkitSpeechRecognition;if(!r)throw new Error("El reconocimiento de voz no está soportado en este navegador");d=new r,d.lang="es-ES",d.continuous=!0,d.interimResults=!0,f&&(d.continuous=!1)}u=n;const t=(e=n.parentElement)==null?void 0:e.querySelector(".btn-voice");d.onstart=()=>{if(console.log("Reconocimiento de voz iniciado"),g=!0,t){t.classList.add("listening");const r=t.querySelector(".fa-microphone");r&&(r.style.color="red")}u.classList.add("listening"),c("Escuchando... Habla ahora","info")},d.onresult=r=>{const o=Array.from(r.results);let a="",s="";o.forEach(i=>{const l=i[0].transcript;i.isFinal?a+=l+" ":s=l}),s&&(u.value=y(s,u.type)),a&&(u.value=y(a,u.type),u.dispatchEvent(new Event("input",{bubbles:!0})),f&&(b(),c("Texto reconocido correctamente","success")))},d.onerror=r=>{console.error("Error en reconocimiento de voz:",r.error),r.error==="not-allowed"?c("Por favor, permite el acceso al micrófono para usar el reconocimiento de voz","warning"):r.error==="no-speech"?c("No se detectó ninguna voz. Por favor, intenta hablar de nuevo","warning"):c("Error en el reconocimiento de voz. Por favor, intenta de nuevo","warning"),b()},d.onend=()=>{console.log("Reconocimiento de voz finalizado"),b(),f&&u&&u.value===""&&setTimeout(()=>{d.start()},100)},d.start()}catch(t){console.error("Error al iniciar reconocimiento de voz:",t),t.name==="NotAllowedError"?c("Por favor, permite el acceso al micrófono para usar el reconocimiento de voz","warning"):c("El reconocimiento de voz no está disponible en este navegador","danger"),b()}}function b(){var n;if(g=!1,u){const e=(n=u.parentElement)==null?void 0:n.querySelector(".btn-voice");if(e){e.classList.remove("listening");const t=e.querySelector(".fa-microphone");t&&(t.style.color="")}u.classList.remove("listening")}if(d)try{d.stop()}catch(e){console.error("Error al detener reconocimiento:",e)}u=null}window.initVoiceRecognition=E;"serviceWorker"in navigator&&window.addEventListener("load",async()=>{try{navigator.mediaDevices&&navigator.mediaDevices.getUserMedia&&(await navigator.mediaDevices.getUserMedia({audio:!0}),console.log("Permiso de micrófono concedido"));const n=window.location.pathname.endsWith("/")?"sw.js":"/sw.js",e=await navigator.serviceWorker.register(n);console.log("Service Worker registrado con éxito:",e.scope)}catch(n){console.error("Error al configurar la aplicación:",n),n.name==="NotAllowedError"&&c("Se requiere permiso para usar el micrófono","warning")}});class N{constructor(){this.jobService=new $,this.workerService=new j,this.ui=new W,this.state={fotosSeleccionadas:[],workerPhotoSelected:null}}async initializeApp(){try{console.log("Inicializando aplicación..."),await Promise.all([this.jobService.init(),this.workerService.init()]),this.setupEventListeners(),await this.renderInitialUI(),console.log("Aplicación inicializada correctamente")}catch(e){throw console.error("Error al inicializar:",e),this.ui.showNotification("Error al inicializar la aplicación","danger"),e}}async renderInitialUI(){await Promise.all([this.renderJobs(),this.renderWorkers(),this.updateWorkerSelect(),this.updateSummary()])}setupEventListeners(){const e=document.querySelector("#jobs-container");e&&e.addEventListener("click",async a=>{const s=a.target.closest("button[data-job-id]");if(!s)return;const i=s.dataset.jobId;if(i)try{s.classList.contains("btn-info")?await this.showJobDetails(i):s.classList.contains("btn-warning")?await this.editJob(i):s.classList.contains("btn-danger")&&await this.deleteJob(i)}catch(l){console.error("Error en acción de trabajo:",l),this.ui.showNotification("Error al procesar la acción","danger")}});const t=document.querySelector("#workers-container");t&&t.addEventListener("click",async a=>{const s=a.target.closest("button[data-worker-id]");if(!s)return;const i=s.dataset.workerId;if(i)try{s.classList.contains("btn-info")?await this.showWorkerDetails(i):s.classList.contains("btn-danger")&&await this.deleteWorker(i)}catch(l){console.error("Error en acción de trabajador:",l),this.ui.showNotification("Error al procesar la acción","danger")}});const r=document.querySelector("#jobForm");r&&r.addEventListener("submit",this.handleJobSubmit.bind(this));const o=document.querySelector("#workerForm");o&&o.addEventListener("submit",this.handleWorkerSubmit.bind(this))}async showJobDetails(e){try{const t=this.jobService.getJobById(e);if(!t){this.ui.showNotification("Trabajo no encontrado","warning");return}t.workerIds&&t.workerIds.length>0&&(t.workers=t.workerIds.map(r=>this.workerService.getWorkerById(r)).filter(Boolean)),this.ui.showJobDetailsModal(t)}catch(t){console.error("Error al mostrar detalles:",t),this.ui.showNotification("Error al mostrar detalles del trabajo","danger")}}async editJob(e){try{const t=this.jobService.getJobById(e);if(!t){this.ui.showNotification("Trabajo no encontrado","warning");return}const r=document.querySelector("#jobForm");if(!r)return;r.querySelector("#titulo").value=t.title,r.querySelector("#descripcion").value=t.description,r.querySelector("#fecha").value=t.date,r.querySelector("#estado").value=t.status;const o=document.querySelector("#trabajador");o&&Array.from(o.options).forEach(s=>{var i;s.selected=(i=t.workerIds)==null?void 0:i.includes(s.value)}),r.dataset.editingJobId=e;const a=r.querySelector('button[type="submit"]');a&&(a.textContent="Actualizar Trabajo"),r.scrollIntoView({behavior:"smooth"})}catch(t){console.error("Error al editar:",t),this.ui.showNotification("Error al cargar el trabajo para editar","danger")}}async deleteJob(e){if(confirm("¿Estás seguro de que deseas eliminar este trabajo?"))try{await this.jobService.deleteJob(e),this.ui.showNotification("Trabajo eliminado con éxito","success"),this.renderJobs(),this.updateSummary()}catch(t){console.error("Error al eliminar:",t),this.ui.showNotification("Error al eliminar el trabajo","danger")}}async handleJobSubmit(e){e.preventDefault();const t=e.target,r=new FormData(t),o=t.dataset.editingJobId;try{const a={id:o||p(),title:r.get("titulo"),description:r.get("descripcion"),date:r.get("fecha"),status:r.get("estado"),workerIds:Array.from(t.querySelector("#trabajador").selectedOptions).map(i=>i.value).filter(Boolean),images:this.state.fotosSeleccionadas,createdAt:o?void 0:new Date().toISOString(),updatedAt:new Date().toISOString()};o?(await this.jobService.updateJob(a),this.ui.showNotification("Trabajo actualizado con éxito","success")):(await this.jobService.addJob(a),this.ui.showNotification("Trabajo guardado con éxito","success")),t.reset(),delete t.dataset.editingJobId;const s=t.querySelector('button[type="submit"]');s&&(s.textContent="Guardar Trabajo"),this.renderJobs(),this.updateSummary()}catch(a){console.error("Error al guardar:",a),this.ui.showNotification("Error al guardar el trabajo","danger")}}renderJobs(){const e=document.querySelector("#jobs-container");if(!e)return;const t=this.jobService.getAllJobs();e.innerHTML=t.map(r=>`
      <div class="list-group-item">
        <div class="d-flex w-100 justify-content-between">
          <h5 class="mb-1">${r.title}</h5>
          <span class="badge bg-${this.getStatusBadgeClass(r.status)}">${r.status}</span>
        </div>
        <p class="mb-1">${r.description}</p>
        <div class="d-flex justify-content-between align-items-center">
          <small class="text-muted">Fecha: ${new Date(r.date).toLocaleDateString()}</small>
          <div class="btn-group">
            <button class="btn btn-sm btn-info" data-job-id="${r.id}" title="Ver detalles">
              <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-warning" data-job-id="${r.id}" title="Editar trabajo">
              <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-danger" data-job-id="${r.id}" title="Eliminar trabajo">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    `).join("")}getStatusBadgeClass(e){return{Pendiente:"warning","En Progreso":"info",Completado:"success"}[e]||"secondary"}updateWorkerSelect(){const e=document.querySelector("#trabajador");if(!e)return;const t=this.workerService.getAllWorkers();e.innerHTML=`
      <option value="">Seleccionar trabajador...</option>
      ${t.map(r=>`
        <option value="${r.id}">${r.name}</option>
      `).join("")}
    `}updateSummary(){const e=document.querySelector("#summarySection");if(!e)return;const t=this.jobService.getJobStats(),r=this.workerService.getWorkerStats();e.innerHTML=`
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="stat-card">
            <h3>${t.total}</h3>
            <p>Trabajos Totales</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="stat-card">
            <h3>${t.completed}</h3>
            <p>Trabajos Completados</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="stat-card">
            <h3>${r.total}</h3>
            <p>Trabajadores</p>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="stat-card">
            <h3>${r.totalHours}</h3>
            <p>Horas Totales</p>
          </div>
        </div>
      </div>
    `}async showWorkerDetails(e){try{const t=this.workerService.getWorkerById(e);t?(t.jobs=this.jobService.getWorkerJobs(e),this.ui.showWorkerDetailsModal(t)):this.ui.showNotification("Trabajador no encontrado","warning")}catch(t){console.error("Error showing worker details:",t),this.ui.showNotification("Error al mostrar detalles del trabajador","danger")}}async deleteWorker(e){if(confirm("¿Estás seguro de que deseas eliminar este trabajador?"))try{await this.workerService.deleteWorker(e),this.ui.showNotification("Trabajador eliminado exitosamente","success"),this.renderWorkers(),this.updateWorkerSelect(),this.updateSummary()}catch(t){console.error("Error deleting worker:",t),this.ui.showNotification("Error al eliminar el trabajador","danger")}}async handleWorkerSubmit(e){e.preventDefault();const t=e.target,r=new FormData(t);try{const o={id:p(),name:r.get("nombre"),specialty:r.get("especialidad"),phone:r.get("telefono"),email:r.get("email"),profileImage:this.state.workerPhotoSelected,createdAt:new Date().toISOString()};await this.workerService.addWorker(o),t.reset(),this.state.workerPhotoSelected=null,this.renderWorkers(),this.updateWorkerSelect(),this.updateSummary()}catch(o){console.error("Error al guardar trabajador:",o),this.ui.showNotification("Error al guardar el trabajador","danger")}}renderWorkers(){const e=document.querySelector("#workers-container");if(!e)return;const t=this.workerService.getAllWorkers();e.innerHTML=t.map(r=>`
      <div class="list-group-item">
        <div class="d-flex w-100 justify-content-between align-items-center">
          <div class="d-flex align-items-center">
            ${r.profileImage?`<img src="${r.profileImage}" alt="${r.name}" class="worker-avatar me-3">`:'<div class="worker-avatar-placeholder me-3"><i class="fas fa-user"></i></div>'}
            <div>
              <h5 class="mb-1">${r.name}</h5>
              <p class="mb-1">${r.specialty}</p>
              <small class="text-muted">
                ${r.email?`<i class="fas fa-envelope me-1"></i>${r.email}`:""}
                ${r.phone?`<i class="fas fa-phone ms-2 me-1"></i>${r.phone}`:""}
              </small>
            </div>
          </div>
          <div class="btn-group">
            <button class="btn btn-sm btn-info" data-worker-id="${r.id}" title="Ver detalles">
              <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-sm btn-danger" data-worker-id="${r.id}" title="Eliminar trabajador">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        </div>
      </div>
    `).join("")}}document.addEventListener("DOMContentLoaded",async()=>{try{window.app=new N,await window.app.initializeApp(),console.log("Aplicación inicializada correctamente"),document.querySelectorAll(".btn-voice").forEach(e=>{const t=e.previousElementSibling;t&&e.addEventListener("click",()=>E(t))})}catch(n){console.error("Error al inicializar la aplicación:",n);const e=document.querySelector("#notification-container");e&&(e.innerHTML=`
        <div class="alert alert-danger">
          Error al inicializar la aplicación
        </div>
      `)}});
//# sourceMappingURL=main-B-AQbj-L.js.map
